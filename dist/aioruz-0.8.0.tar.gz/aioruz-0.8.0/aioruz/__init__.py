from .api import (Lesson,
                  is_hse_email,
                  is_student_email,
                  person_type_from_email,
                  search, student_info,
                  schedule,
                  student_schedule,
                  VERIFY_SSL)

name = "aioruz"
__version__ = (0.8)
