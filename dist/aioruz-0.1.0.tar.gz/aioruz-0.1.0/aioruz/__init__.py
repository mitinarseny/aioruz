from .api import is_hse_email, is_student_email, person_type_from_email, search, student_info, schedule, student_schedule

name = "aioruz"
__version__ = (0.1)


